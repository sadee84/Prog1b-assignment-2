# Wildlife Rescue Operations System

PROG6112 Practical Assignment - console-based Java application for WildLife SA.

## What it does
Staff can record and manage rescue cases (Injured, Orphaned, Endangered), search by Rescue Case ID, update status, start/complete rescues, view all cases and print a rescue report. All cases are stored in an `ArrayList`.

## Project layout
```
WildlifeRescueSystem/
  pom.xml                      Maven settings (JUnit 5)
  src/main/java/               application code
  src/test/java/               JUnit tests (RescueSystemTest.java)
  docs/CODE_EXPLANATION.md     step-by-step explanation of the code
```

## How the spec is covered
| Requirement | Where |
|---|---|
| Rescue case management (create, search, update, display, ArrayList) | `RescueManager`, `Main` |
| Rescue types with own cost, priority, details | `InjuredAnimalRescue`, `OrphanedAnimalRescue`, `EndangeredSpeciesRescue` |
| Start / complete / summary | `RescueOperations`, `RescueCase` |
| Report | `RescueManager.generateReport()` |
| Validation | `InputHelper`, constructors in `RescueCase` and subclasses |
| JUnit tests (21) | `RescueSystemTest` |
| Inheritance, abstraction, interfaces, encapsulation, overriding, polymorphism | see `docs/CODE_EXPLANATION.md` |

## Run it
**NetBeans:** File > Open Project > select the `WildlifeRescueSystem` folder. Right-click `Main.java` > Run File. Right-click the project > Test to run the JUnit tests.

**Terminal (needs JDK 17+ and Maven):**
```
mvn test
mvn compile exec:java
```

## Code attribution and AI-use declaration
Claude (Anthropic, 2026), a large language model, was used to generate and structure the code in this project. The code was compiled, run and tested (21 JUnit tests passing) and the sample report matches the assignment example (total R32 000.00). The submitting student must read, understand and be able to explain all code, and must follow The IIE's policy on the use of AI tools, including declaring this use where required.

## Reference list (Harvard)
Anthropic (2026) *Claude* [Large language model]. Available at: https://claude.ai (Accessed: 12 October 2026).

JUnit Team (2024) *JUnit 5 User Guide*. Available at: https://junit.org/junit5/docs/current/user-guide/ (Accessed: 12 October 2026).

Oracle (2024) *Java Platform, Standard Edition 21 API Specification*. Available at: https://docs.oracle.com/en/java/javase/21/docs/api/ (Accessed: 12 October 2026).

*In-text examples:* (Anthropic, 2026); (Oracle, 2024); (JUnit Team, 2024).

# Code explanation (step by step)

## 1. The big idea
A rescue case has things every case shares (ID, species, ranger...) and things only one type has (surgery, foster care...). So we use **inheritance**: one parent class, three child classes.

## 2. The classes
| Class | Job |
|---|---|
| `RescueCase` (abstract) | Parent. Stores the shared data and does the shared work. |
| `InjuredAnimalRescue`, `OrphanedAnimalRescue`, `EndangeredSpeciesRescue` | Children. Add their own data and their own cost/priority rules. |
| `RescueManager` | Holds the `ArrayList<RescueCase>`, searches it, builds the report. |
| `Main` | The menu. Talks to the user and calls `RescueManager`. |
| `InputHelper` | Reads and validates what the user types. |
| `Money`, `RescueStatus`, `RescuePriority`, `ConservationClassification` | Helpers and enums. |

## 3. How each OOP requirement is met
1. **Inheritance** - `InjuredAnimalRescue extends RescueCase`.
2. **Abstraction** - `RescueCase` is `abstract`; you cannot do `new RescueCase()`. It declares abstract methods (`getRescueType`, `calculateTypeSpecificCost`, `getTypeSpecificDetails`) that every child must write.
3. **Interfaces** - `RescueOperations` (start, complete, summary) and `Assessable` (cost, priority). `RescueCase` implements both.
4. **Encapsulation** - fields are `private`; other classes use getters. Status can only change through `setStatus`, `startRescue` and `completeRescue`.
5. **Method overriding** - each child overrides `determinePriority()` and the abstract cost/detail methods with `@Override`.
6. **Polymorphism** - `RescueManager` keeps `ArrayList<RescueCase>`. When it calls `c.calculateTotalCost()`, Java runs the correct child version automatically.

## 4. Cost rules
Total = (rescue days x daily care cost) + type cost.
- Injured: vet cost + R5 000 if surgery required.
- Orphaned: feeding cost + R2 500 if foster care required.
- Endangered: security cost + R8 000 if specialist team required.

Example: 5 days x R1 500 = R7 500, + R8 000 vet + R5 000 surgery = **R20 500**.

## 5. Priority rules (our design choice, the spec only says "appropriate")
- Injured: surgery = Critical; vet cost over R10 000 = High; otherwise Medium.
- Orphaned: 6 months or younger = High; up to 24 months = Medium; older = Low.
- Endangered: Critically Endangered = Critical; Endangered = High; Vulnerable = Medium.

## 6. Status rules
Reported -> Rescue in Progress -> (Under Observation) -> Rescue Completed. A rescue cannot be completed before it is started; the code throws an `IllegalStateException` and `Main` prints a friendly error.

## 7. Validation
`InputHelper` loops until the input is valid (not blank, numbers above zero, valid menu choice). `RescueManager.idExists` stops duplicate IDs. The program never crashes on bad input.

## 8. Tests
`RescueSystemTest` has 21 tests covering costs, priorities, status updates, searching and duplicate IDs. `assertEquals` checks a value, `assertThrows` checks that an error is thrown, `assertSame` checks it is the same object (JUnit Team, 2024).

/*
 * File: Main.java
 * Project: Wildlife Rescue Operations System (PROG6112 Practical Assignment)
 * Purpose: Console menu (front end) that lets staff create, search, update, display and report on rescue cases.
 *
 * Code attribution / AI-use declaration:
 * The structure and code in this file were generated with the assistance of
 * Claude (Anthropic, 2026) and then compiled, tested and reviewed. Language features
 * follow the Java documentation (Oracle, 2024).
 * Full Harvard reference list is in README.md.
 */

import java.util.Scanner;

/** Console front end for the Wildlife Rescue Operations System. */
public class Main {

    private static final RescueManager manager = new RescueManager();
    private static InputHelper input;

    public static void main(String[] args) {
        input = new InputHelper(new Scanner(System.in));
        boolean running = true;

        while (running) {
            printMenu();
            int choice = input.readMenuChoice("Select an option: ", 1, 6);
            System.out.println();
            switch (choice) {
                case 1: createRescueCase(); break;
                case 2: searchRescueCase(); break;
                case 3: updateRescueStatus(); break;
                case 4: displayAllCases(); break;
                case 5: System.out.println(manager.generateReport()); break;
                case 6:
                    System.out.println("Thank you for using the Wildlife Rescue Operations System. Goodbye!");
                    running = false;
                    break;
                default: break;
            }
        }
    }

    private static void printMenu() {
        System.out.println("=".repeat(40));
        System.out.println("WILDLIFE RESCUE OPERATIONS SYSTEM");
        System.out.println("=".repeat(40));
        System.out.println();
        System.out.println("1. Create Rescue Case");
        System.out.println("2. Search Rescue Case");
        System.out.println("3. Update Rescue Status");
        System.out.println("4. Display All Rescue Cases");
        System.out.println("5. Rescue Report");
        System.out.println("6. Exit");
        System.out.println();
    }

    private static void createRescueCase() {
        System.out.println("Rescue types:");
        System.out.println("1. Injured Animal Rescue");
        System.out.println("2. Orphaned Animal Rescue");
        System.out.println("3. Endangered Species Rescue");
        int type = input.readMenuChoice("Select rescue type: ", 1, 3);

        String id;
        while (true) {
            id = input.readNonBlank("Rescue Case ID: ", "Rescue Case ID");
            if (!manager.idExists(id)) break;
            System.out.println("Error: that Rescue Case ID already exists. Enter a unique ID.");
        }
        String name = input.readOptional("Animal Name (optional): ");
        String species = input.readNonBlank("Species: ", "Species");
        String location = input.readNonBlank("Rescue Location: ", "Rescue Location");
        String ranger = input.readNonBlank("Assigned Ranger: ", "Assigned Ranger");
        int days = input.readPositiveInt("Number of Rescue Days: ", "Number of rescue days");
        double daily = input.readPositiveDouble("Daily Care Cost (R): ", "Daily care cost");

        RescueCase newCase;
        switch (type) {
            case 1: {
                String injury = input.readNonBlank("Injury Description: ", "Injury description");
                double vet = input.readPositiveDouble("Veterinary Treatment Cost (R): ", "Veterinary treatment cost");
                boolean surgery = input.readYesNo("Surgery required?");
                newCase = new InjuredAnimalRescue(id, name, species, location, ranger, days, daily,
                        injury, vet, surgery);
                break;
            }
            case 2: {
                int age = input.readPositiveInt("Estimated Age (Months): ", "Estimated age");
                double feeding = input.readPositiveDouble("Feeding Cost (R): ", "Feeding cost");
                boolean foster = input.readYesNo("Foster care required?");
                newCase = new OrphanedAnimalRescue(id, name, species, location, ranger, days, daily,
                        age, feeding, foster);
                break;
            }
            default: {
                System.out.println("Conservation Classification:");
                System.out.println("1. Vulnerable");
                System.out.println("2. Endangered");
                System.out.println("3. Critically Endangered");
                int c = input.readMenuChoice("Select classification: ", 1, 3);
                ConservationClassification classification = ConservationClassification.values()[c - 1];
                double security = input.readPositiveDouble("Security Cost (R): ", "Security cost");
                boolean team = input.readYesNo("Specialist team required?");
                newCase = new EndangeredSpeciesRescue(id, name, species, location, ranger, days, daily,
                        classification, security, team);
                break;
            }
        }

        manager.addCase(newCase);
        System.out.println();
        System.out.println("Rescue case created successfully.");
        System.out.println(newCase.generateSummary());

        if (input.readYesNo("Start this rescue operation now?")) {
            newCase.startRescue();
            System.out.println("Rescue started. Status: " + newCase.getStatus());
        }
        System.out.println();
    }

    private static void searchRescueCase() {
        String id = input.readNonBlank("Enter Rescue Case ID: ", "Rescue Case ID");
        RescueCase found = manager.findById(id);
        System.out.println();
        if (found == null) {
            System.out.println("No rescue case found with ID " + id.toUpperCase() + ".");
        } else {
            System.out.println(found.displayDetails());
        }
    }

    private static void updateRescueStatus() {
        String id = input.readNonBlank("Enter Rescue Case ID: ", "Rescue Case ID");
        RescueCase found = manager.findById(id);
        if (found == null) {
            System.out.println("No rescue case found with ID " + id.toUpperCase() + ".");
            System.out.println();
            return;
        }
        System.out.println("Current status: " + found.getStatus());
        System.out.println("1. Reported");
        System.out.println("2. Rescue in Progress (start rescue)");
        System.out.println("3. Under Observation");
        System.out.println("4. Rescue Completed (complete rescue)");
        int choice = input.readMenuChoice("Select new status: ", 1, 4);

        try {
            switch (choice) {
                case 1: found.setStatus(RescueStatus.REPORTED); break;
                case 2: found.startRescue(); break;
                case 3: found.setStatus(RescueStatus.UNDER_OBSERVATION); break;
                default: found.completeRescue(); break;
            }
            System.out.println("Status updated. New status: " + found.getStatus());
        } catch (IllegalStateException e) {
            System.out.println("Error: " + e.getMessage());
        }
        System.out.println();
    }

    private static void displayAllCases() {
        if (manager.getTotalCases() == 0) {
            System.out.println("No rescue cases have been recorded.");
            System.out.println();
            return;
        }
        for (RescueCase c : manager.getAllCases()) {
            System.out.println(c.displayDetails());
            System.out.println("-".repeat(52));
        }
        System.out.println();
    }
}

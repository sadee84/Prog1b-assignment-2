/*
 * File: RescueOperations.java
 * Project: Wildlife Rescue Operations System (PROG6112 Practical Assignment)
 * Purpose: Interface listing the operations every rescue case must support (start, complete, summary).
 *
 * Code attribution / AI-use declaration:
 * The structure and code in this file were generated with the assistance of
 * Claude (Anthropic, 2026) and then compiled, tested and reviewed. Language features
 * follow the Java documentation (Oracle, 2024).
 * Full Harvard reference list is in README.md.
 */

/** Operations that every rescue case must support. */
public interface RescueOperations {
    void startRescue();

    void completeRescue();

    String generateSummary();
}

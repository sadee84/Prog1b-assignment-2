/*
 * File: Assessable.java
 * Project: Wildlife Rescue Operations System (PROG6112 Practical Assignment)
 * Purpose: Interface for anything that can calculate its own total cost and priority.
 *
 * Code attribution / AI-use declaration:
 * The structure and code in this file were generated with the assistance of
 * Claude (Anthropic, 2026) and then compiled, tested and reviewed. Language features
 * follow the Java documentation (Oracle, 2024).
 * Full Harvard reference list is in README.md.
 */

/** Anything that can work out its own cost and priority. */
public interface Assessable {
    double calculateTotalCost();

    RescuePriority determinePriority();
}

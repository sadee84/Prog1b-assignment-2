/*
 * File: OrphanedAnimalRescue.java
 * Project: Wildlife Rescue Operations System (PROG6112 Practical Assignment)
 * Purpose: Child class for orphaned animals: own cost (feeding + R2 500 foster surcharge), priority and details (method overriding).
 *
 * Code attribution / AI-use declaration:
 * The structure and code in this file were generated with the assistance of
 * Claude (Anthropic, 2026) and then compiled, tested and reviewed. Language features
 * follow the Java documentation (Oracle, 2024).
 * Full Harvard reference list is in README.md.
 */

/** A rescue of an orphaned animal. */
public class OrphanedAnimalRescue extends RescueCase {

    public static final double FOSTER_CARE_SURCHARGE = 2500.00;

    private final int estimatedAgeMonths;
    private final double feedingCost;
    private final boolean fosterCareRequired;

    public OrphanedAnimalRescue(String caseId, String animalName, String species, String location,
                                String assignedRanger, int rescueDays, double dailyCareCost,
                                int estimatedAgeMonths, double feedingCost, boolean fosterCareRequired) {
        super(caseId, animalName, species, location, assignedRanger, rescueDays, dailyCareCost);
        if (estimatedAgeMonths <= 0) throw new IllegalArgumentException("Estimated age must be greater than zero.");
        if (feedingCost <= 0) throw new IllegalArgumentException("Feeding cost must be greater than zero.");
        this.estimatedAgeMonths = estimatedAgeMonths;
        this.feedingCost = feedingCost;
        this.fosterCareRequired = fosterCareRequired;
    }

    @Override
    public String getRescueType() {
        return "Orphaned Animal Rescue";
    }

    @Override
    protected double calculateTypeSpecificCost() {
        return feedingCost + (fosterCareRequired ? FOSTER_CARE_SURCHARGE : 0);
    }

    /** The younger the animal, the more urgent the rescue. */
    @Override
    public RescuePriority determinePriority() {
        if (estimatedAgeMonths <= 6) return RescuePriority.HIGH;
        if (estimatedAgeMonths <= 24) return RescuePriority.MEDIUM;
        return RescuePriority.LOW;
    }

    @Override
    public String getTypeSpecificDetails() {
        return String.format("%-14s: %d%n", "Age (Months)", estimatedAgeMonths)
                + String.format("%-14s: %s%n", "Feeding Cost", Money.format(feedingCost))
                + String.format("%-14s: %s%n", "Foster Care", fosterCareRequired ? "Yes" : "No");
    }

    public int getEstimatedAgeMonths() { return estimatedAgeMonths; }
    public boolean isFosterCareRequired() { return fosterCareRequired; }
}

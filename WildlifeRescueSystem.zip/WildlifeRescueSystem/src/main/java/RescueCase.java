/*
 * File: RescueCase.java
 * Project: Wildlife Rescue Operations System (PROG6112 Practical Assignment)
 * Purpose: Abstract parent class holding the data and behaviour shared by all rescue types (inheritance, abstraction, encapsulation).
 *
 * Code attribution / AI-use declaration:
 * The structure and code in this file were generated with the assistance of
 * Claude (Anthropic, 2026) and then compiled, tested and reviewed. Language features
 * follow the Java documentation (Oracle, 2024).
 * Full Harvard reference list is in README.md.
 */

/**
 * Abstract base class for all rescue cases. Holds the common data and the
 * shared rescue operations; subclasses supply their own cost, priority and
 * type-specific details.
 */
public abstract class RescueCase implements RescueOperations, Assessable {

    private final String caseId;
    private final String animalName;
    private final String species;
    private final String location;
    private final String assignedRanger;
    private final int rescueDays;
    private final double dailyCareCost;
    private RescueStatus status;

    protected RescueCase(String caseId, String animalName, String species, String location,
                         String assignedRanger, int rescueDays, double dailyCareCost) {
        if (isBlank(caseId)) throw new IllegalArgumentException("Rescue Case ID cannot be blank.");
        if (isBlank(species)) throw new IllegalArgumentException("Species cannot be blank.");
        if (isBlank(location)) throw new IllegalArgumentException("Rescue Location cannot be blank.");
        if (isBlank(assignedRanger)) throw new IllegalArgumentException("Assigned Ranger cannot be blank.");
        if (rescueDays <= 0) throw new IllegalArgumentException("Number of rescue days must be greater than zero.");
        if (dailyCareCost <= 0) throw new IllegalArgumentException("Daily care cost must be greater than zero.");

        this.caseId = caseId.trim().toUpperCase();
        this.animalName = isBlank(animalName) ? "Unnamed" : animalName.trim();
        this.species = species.trim();
        this.location = location.trim();
        this.assignedRanger = assignedRanger.trim();
        this.rescueDays = rescueDays;
        this.dailyCareCost = dailyCareCost;
        this.status = RescueStatus.REPORTED;
    }

    protected static boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }

    // ----- Abstract behaviour supplied by each rescue type -----

    /** Display name of the rescue type, e.g. "Injured Animal Rescue". */
    public abstract String getRescueType();

    /** The cost that is specific to this rescue type (treatment, feeding, security + surcharges). */
    protected abstract double calculateTypeSpecificCost();

    /** Lines of information that only apply to this rescue type. */
    public abstract String getTypeSpecificDetails();

    // ----- Shared behaviour -----

    /** Total = (days x daily care cost) + type-specific costs. */
    @Override
    public double calculateTotalCost() {
        return (rescueDays * dailyCareCost) + calculateTypeSpecificCost();
    }

    @Override
    public void startRescue() {
        if (status == RescueStatus.COMPLETED) {
            throw new IllegalStateException("This rescue has already been completed.");
        }
        if (status == RescueStatus.IN_PROGRESS) {
            throw new IllegalStateException("This rescue is already in progress.");
        }
        status = RescueStatus.IN_PROGRESS;
    }

    @Override
    public void completeRescue() {
        if (status == RescueStatus.COMPLETED) {
            throw new IllegalStateException("This rescue has already been completed.");
        }
        if (status == RescueStatus.REPORTED) {
            throw new IllegalStateException("The rescue must be started before it can be completed.");
        }
        status = RescueStatus.COMPLETED;
    }

    @Override
    public String generateSummary() {
        return String.format("%-14s: %s%n", "Case ID", caseId)
                + String.format("%-14s: %s%n", "Type", getRescueType())
                + String.format("%-14s: %s%n", "Species", species)
                + String.format("%-14s: %s%n", "Ranger", assignedRanger)
                + String.format("%-14s: %s%n", "Priority", determinePriority())
                + String.format("%-14s: %s%n", "Status", status)
                + String.format("%-14s: %s%n", "Total Cost", Money.format(calculateTotalCost()));
    }

    /** Full details including the type-specific information. */
    public String displayDetails() {
        return String.format("%-14s: %s%n", "Case ID", caseId)
                + String.format("%-14s: %s%n", "Type", getRescueType())
                + String.format("%-14s: %s%n", "Animal Name", animalName)
                + String.format("%-14s: %s%n", "Species", species)
                + String.format("%-14s: %s%n", "Location", location)
                + String.format("%-14s: %s%n", "Ranger", assignedRanger)
                + String.format("%-14s: %d%n", "Rescue Days", rescueDays)
                + String.format("%-14s: %s%n", "Daily Care", Money.format(dailyCareCost))
                + getTypeSpecificDetails()
                + String.format("%-14s: %s%n", "Priority", determinePriority())
                + String.format("%-14s: %s%n", "Status", status)
                + String.format("%-14s: %s%n", "Total Cost", Money.format(calculateTotalCost()));
    }

    // ----- Getters / controlled setter (encapsulation) -----

    public String getCaseId() { return caseId; }
    public String getAnimalName() { return animalName; }
    public String getSpecies() { return species; }
    public String getLocation() { return location; }
    public String getAssignedRanger() { return assignedRanger; }
    public int getRescueDays() { return rescueDays; }
    public double getDailyCareCost() { return dailyCareCost; }
    public RescueStatus getStatus() { return status; }

    public void setStatus(RescueStatus status) {
        if (status == null) throw new IllegalArgumentException("Status cannot be null.");
        this.status = status;
    }
}

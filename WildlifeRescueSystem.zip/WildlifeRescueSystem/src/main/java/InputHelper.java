/*
 * File: InputHelper.java
 * Project: Wildlife Rescue Operations System (PROG6112 Practical Assignment)
 * Purpose: Reads console input with a Scanner and keeps asking until it is valid, so the program never crashes on bad input.
 *
 * Code attribution / AI-use declaration:
 * The structure and code in this file were generated with the assistance of
 * Claude (Anthropic, 2026) and then compiled, tested and reviewed. Language features
 * follow the Java documentation (Oracle, 2024).
 * Full Harvard reference list is in README.md.
 */

import java.util.Scanner;

/** Reads and validates console input. Keeps asking until the input is valid. */
public class InputHelper {

    private final Scanner scanner;

    public InputHelper(Scanner scanner) {
        this.scanner = scanner;
    }

    public String readNonBlank(String prompt, String fieldName) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            if (!input.isEmpty()) return input;
            System.out.println("Error: " + fieldName + " cannot be blank. Please try again.");
        }
    }

    /** Optional text; returns an empty string if the user just presses Enter. */
    public String readOptional(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }

    public int readPositiveInt(String prompt, String fieldName) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                int value = Integer.parseInt(input);
                if (value > 0) return value;
                System.out.println("Error: " + fieldName + " must be greater than zero.");
            } catch (NumberFormatException e) {
                System.out.println("Error: " + fieldName + " must be a whole number.");
            }
        }
    }

    public double readPositiveDouble(String prompt, String fieldName) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim().replace(',', '.');
            try {
                double value = Double.parseDouble(input);
                if (value > 0) return value;
                System.out.println("Error: " + fieldName + " must be greater than zero.");
            } catch (NumberFormatException e) {
                System.out.println("Error: " + fieldName + " must be a number.");
            }
        }
    }

    public boolean readYesNo(String prompt) {
        while (true) {
            System.out.print(prompt + " (Y/N): ");
            String input = scanner.nextLine().trim().toUpperCase();
            if (input.equals("Y") || input.equals("YES")) return true;
            if (input.equals("N") || input.equals("NO")) return false;
            System.out.println("Error: please enter Y or N.");
        }
    }

    /** Reads a menu number between min and max (inclusive). */
    public int readMenuChoice(String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                int choice = Integer.parseInt(input);
                if (choice >= min && choice <= max) return choice;
            } catch (NumberFormatException e) {
                // fall through to the error message
            }
            System.out.println("Error: invalid selection. Enter a number from " + min + " to " + max + ".");
        }
    }
}

/*
 * File: InjuredAnimalRescue.java
 * Project: Wildlife Rescue Operations System (PROG6112 Practical Assignment)
 * Purpose: Child class for injured animals: own cost (vet + R5 000 surgery surcharge), priority and details (method overriding).
 *
 * Code attribution / AI-use declaration:
 * The structure and code in this file were generated with the assistance of
 * Claude (Anthropic, 2026) and then compiled, tested and reviewed. Language features
 * follow the Java documentation (Oracle, 2024).
 * Full Harvard reference list is in README.md.
 */

/** A rescue of an injured animal. */
public class InjuredAnimalRescue extends RescueCase {

    public static final double SURGERY_SURCHARGE = 5000.00;
    /** Treatment costs above this amount raise the priority to High. */
    public static final double HIGH_TREATMENT_THRESHOLD = 10000.00;

    private final String injuryDescription;
    private final double veterinaryTreatmentCost;
    private final boolean surgeryRequired;

    public InjuredAnimalRescue(String caseId, String animalName, String species, String location,
                               String assignedRanger, int rescueDays, double dailyCareCost,
                               String injuryDescription, double veterinaryTreatmentCost,
                               boolean surgeryRequired) {
        super(caseId, animalName, species, location, assignedRanger, rescueDays, dailyCareCost);
        if (isBlank(injuryDescription)) throw new IllegalArgumentException("Injury description cannot be blank.");
        if (veterinaryTreatmentCost <= 0) throw new IllegalArgumentException("Veterinary treatment cost must be greater than zero.");
        this.injuryDescription = injuryDescription.trim();
        this.veterinaryTreatmentCost = veterinaryTreatmentCost;
        this.surgeryRequired = surgeryRequired;
    }

    @Override
    public String getRescueType() {
        return "Injured Animal Rescue";
    }

    @Override
    protected double calculateTypeSpecificCost() {
        return veterinaryTreatmentCost + (surgeryRequired ? SURGERY_SURCHARGE : 0);
    }

    @Override
    public RescuePriority determinePriority() {
        if (surgeryRequired) return RescuePriority.CRITICAL;
        if (veterinaryTreatmentCost > HIGH_TREATMENT_THRESHOLD) return RescuePriority.HIGH;
        return RescuePriority.MEDIUM;
    }

    @Override
    public String getTypeSpecificDetails() {
        return String.format("%-14s: %s%n", "Injury", injuryDescription)
                + String.format("%-14s: %s%n", "Vet Cost", Money.format(veterinaryTreatmentCost))
                + String.format("%-14s: %s%n", "Surgery", surgeryRequired ? "Yes" : "No");
    }

    public boolean isSurgeryRequired() { return surgeryRequired; }
    public double getVeterinaryTreatmentCost() { return veterinaryTreatmentCost; }
    public String getInjuryDescription() { return injuryDescription; }
}

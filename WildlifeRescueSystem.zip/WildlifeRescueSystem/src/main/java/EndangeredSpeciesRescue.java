/*
 * File: EndangeredSpeciesRescue.java
 * Project: Wildlife Rescue Operations System (PROG6112 Practical Assignment)
 * Purpose: Child class for endangered species: own cost (security + R8 000 specialist team surcharge), priority and details.
 *
 * Code attribution / AI-use declaration:
 * The structure and code in this file were generated with the assistance of
 * Claude (Anthropic, 2026) and then compiled, tested and reviewed. Language features
 * follow the Java documentation (Oracle, 2024).
 * Full Harvard reference list is in README.md.
 */

/** A rescue of an endangered species. */
public class EndangeredSpeciesRescue extends RescueCase {

    public static final double SPECIALIST_TEAM_SURCHARGE = 8000.00;

    private final ConservationClassification classification;
    private final double securityCost;
    private final boolean specialistTeamRequired;

    public EndangeredSpeciesRescue(String caseId, String animalName, String species, String location,
                                   String assignedRanger, int rescueDays, double dailyCareCost,
                                   ConservationClassification classification, double securityCost,
                                   boolean specialistTeamRequired) {
        super(caseId, animalName, species, location, assignedRanger, rescueDays, dailyCareCost);
        if (classification == null) throw new IllegalArgumentException("Conservation classification is required.");
        if (securityCost <= 0) throw new IllegalArgumentException("Security cost must be greater than zero.");
        this.classification = classification;
        this.securityCost = securityCost;
        this.specialistTeamRequired = specialistTeamRequired;
    }

    @Override
    public String getRescueType() {
        return "Endangered Species Rescue";
    }

    @Override
    protected double calculateTypeSpecificCost() {
        return securityCost + (specialistTeamRequired ? SPECIALIST_TEAM_SURCHARGE : 0);
    }

    @Override
    public RescuePriority determinePriority() {
        switch (classification) {
            case CRITICALLY_ENDANGERED:
                return RescuePriority.CRITICAL;
            case ENDANGERED:
                return RescuePriority.HIGH;
            default:
                return RescuePriority.MEDIUM;
        }
    }

    @Override
    public String getTypeSpecificDetails() {
        return String.format("%-14s: %s%n", "Classification", classification)
                + String.format("%-14s: %s%n", "Security Cost", Money.format(securityCost))
                + String.format("%-14s: %s%n", "Specialist Team", specialistTeamRequired ? "Yes" : "No");
    }

    public ConservationClassification getClassification() { return classification; }
    public boolean isSpecialistTeamRequired() { return specialistTeamRequired; }
}

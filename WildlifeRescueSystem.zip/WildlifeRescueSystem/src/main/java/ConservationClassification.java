/*
 * File: ConservationClassification.java
 * Project: Wildlife Rescue Operations System (PROG6112 Practical Assignment)
 * Purpose: Enum of conservation classifications used by endangered species rescues.
 *
 * Code attribution / AI-use declaration:
 * The structure and code in this file were generated with the assistance of
 * Claude (Anthropic, 2026) and then compiled, tested and reviewed. Language features
 * follow the Java documentation (Oracle, 2024).
 * Full Harvard reference list is in README.md.
 */

/** Conservation classification used by endangered species rescues. */
public enum ConservationClassification {
    VULNERABLE("Vulnerable"),
    ENDANGERED("Endangered"),
    CRITICALLY_ENDANGERED("Critically Endangered");

    private final String label;

    ConservationClassification(String label) {
        this.label = label;
    }

    @Override
    public String toString() {
        return label;
    }
}

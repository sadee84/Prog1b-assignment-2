/*
 * File: RescuePriority.java
 * Project: Wildlife Rescue Operations System (PROG6112 Practical Assignment)
 * Purpose: Enum of the possible rescue priorities.
 *
 * Code attribution / AI-use declaration:
 * The structure and code in this file were generated with the assistance of
 * Claude (Anthropic, 2026) and then compiled, tested and reviewed. Language features
 * follow the Java documentation (Oracle, 2024).
 * Full Harvard reference list is in README.md.
 */

/** How urgently a rescue case needs attention. */
public enum RescuePriority {
    CRITICAL("Critical"),
    HIGH("High"),
    MEDIUM("Medium"),
    LOW("Low");

    private final String label;

    RescuePriority(String label) {
        this.label = label;
    }

    @Override
    public String toString() {
        return label;
    }
}

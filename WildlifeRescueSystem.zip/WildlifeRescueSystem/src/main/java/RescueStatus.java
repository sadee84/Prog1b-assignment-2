/*
 * File: RescueStatus.java
 * Project: Wildlife Rescue Operations System (PROG6112 Practical Assignment)
 * Purpose: Enum of the possible rescue statuses.
 *
 * Code attribution / AI-use declaration:
 * The structure and code in this file were generated with the assistance of
 * Claude (Anthropic, 2026) and then compiled, tested and reviewed. Language features
 * follow the Java documentation (Oracle, 2024).
 * Full Harvard reference list is in README.md.
 */

/** The lifecycle states of a rescue case. */
public enum RescueStatus {
    REPORTED("Reported"),
    IN_PROGRESS("Rescue in Progress"),
    UNDER_OBSERVATION("Under Observation"),
    COMPLETED("Rescue Completed");

    private final String label;

    RescueStatus(String label) {
        this.label = label;
    }

    @Override
    public String toString() {
        return label;
    }
}

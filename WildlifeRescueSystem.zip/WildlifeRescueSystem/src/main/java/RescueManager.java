/*
 * File: RescueManager.java
 * Project: Wildlife Rescue Operations System (PROG6112 Practical Assignment)
 * Purpose: Stores every rescue case in an ArrayList and handles searching, duplicate-ID checks and the report.
 *
 * Code attribution / AI-use declaration:
 * The structure and code in this file were generated with the assistance of
 * Claude (Anthropic, 2026) and then compiled, tested and reviewed. Language features
 * follow the Java documentation (Oracle, 2024).
 * Full Harvard reference list is in README.md.
 */

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Stores and manages all rescue cases in an ArrayList. */
public class RescueManager {

    private static final String DOUBLE_LINE = "=".repeat(52);
    private static final String SINGLE_LINE = "-".repeat(52);

    private final ArrayList<RescueCase> rescueCases = new ArrayList<>();

    public boolean idExists(String caseId) {
        return findById(caseId) != null;
    }

    /** Adds a case. Throws if the ID is already used. */
    public void addCase(RescueCase rescueCase) {
        if (rescueCase == null) throw new IllegalArgumentException("Rescue case cannot be null.");
        if (idExists(rescueCase.getCaseId())) {
            throw new IllegalArgumentException("Rescue Case ID " + rescueCase.getCaseId() + " already exists.");
        }
        rescueCases.add(rescueCase);
    }

    /** Returns the matching case (ignoring case), or null if not found. */
    public RescueCase findById(String caseId) {
        if (caseId == null) return null;
        String wanted = caseId.trim();
        for (RescueCase c : rescueCases) {
            if (c.getCaseId().equalsIgnoreCase(wanted)) return c;
        }
        return null;
    }

    public boolean updateStatus(String caseId, RescueStatus newStatus) {
        RescueCase c = findById(caseId);
        if (c == null) return false;
        c.setStatus(newStatus);
        return true;
    }

    public List<RescueCase> getAllCases() {
        return Collections.unmodifiableList(rescueCases);
    }

    public int getTotalCases() {
        return rescueCases.size();
    }

    public double getTotalRescueCost() {
        double total = 0;
        for (RescueCase c : rescueCases) total += c.calculateTotalCost();
        return total;
    }

    public String generateReport() {
        StringBuilder sb = new StringBuilder();
        sb.append(DOUBLE_LINE).append(System.lineSeparator());
        sb.append("WILDLIFE RESCUE REPORT").append(System.lineSeparator());
        sb.append(DOUBLE_LINE).append(System.lineSeparator()).append(System.lineSeparator());

        if (rescueCases.isEmpty()) {
            sb.append("No rescue cases have been recorded.").append(System.lineSeparator());
            sb.append(System.lineSeparator());
        }
        for (RescueCase c : rescueCases) {
            sb.append(String.format("%-14s: %s%n", "Case ID", c.getCaseId()));
            sb.append(String.format("%-14s: %s%n", "Type", c.getRescueType()));
            sb.append(String.format("%-14s: %s%n", "Species", c.getSpecies()));
            sb.append(String.format("%-14s: %s%n", "Location", c.getLocation()));
            sb.append(String.format("%-14s: %s%n", "Ranger", c.getAssignedRanger()));
            sb.append(String.format("%-14s: %s%n", "Priority", c.determinePriority()));
            sb.append(String.format("%-14s: %s%n", "Status", c.getStatus()));
            sb.append(String.format("%-14s: %s%n", "Total Cost", Money.format(c.calculateTotalCost())));
            sb.append(SINGLE_LINE).append(System.lineSeparator());
        }

        sb.append(DOUBLE_LINE).append(System.lineSeparator());
        sb.append(String.format("%-20s: %d%n", "Total Rescue Cases", getTotalCases()));
        sb.append(String.format("%-20s: %s%n", "Total Rescue Cost", Money.format(getTotalRescueCost())));
        return sb.toString();
    }
}

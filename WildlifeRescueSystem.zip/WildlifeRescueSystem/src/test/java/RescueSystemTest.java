/*
 * File: RescueSystemTest.java
 * Project: Wildlife Rescue Operations System (PROG6112 Practical Assignment)
 * Purpose: JUnit 5 tests for cost, priority, status updates, searching and duplicate IDs.
 *
 * Code attribution / AI-use declaration:
 * The structure and code in this file were generated with the assistance of
 * Claude (Anthropic, 2026) and then compiled, tested and reviewed. Language features
 * follow the Java documentation (Oracle, 2024) and the JUnit 5 User Guide (JUnit Team, 2024).
 * Full Harvard reference list is in README.md.
 */

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/** JUnit 5 tests for the Wildlife Rescue Operations System. */
class RescueSystemTest {

    private RescueManager manager;
    private InjuredAnimalRescue elephant;
    private OrphanedAnimalRescue rhino;

    @BeforeEach
    void setUp() {
        manager = new RescueManager();
        // 5 days x R1 500 + R8 000 vet + R5 000 surgery = R20 500
        elephant = new InjuredAnimalRescue("WR101", "Tembo", "African Elephant", "Kruger National Park",
                "Ranger Dlamini", 5, 1500.00, "Snare wound on foreleg", 8000.00, true);
        // 4 days x R1 500 + R3 000 feeding + R2 500 foster = R11 500
        rhino = new OrphanedAnimalRescue("WR102", "Thandi", "White Rhino", "Hluhluwe",
                "Ranger Naidoo", 4, 1500.00, 4, 3000.00, true);
    }

    // ----- Cost calculations -----

    @Test
    void injuredRescueCostIncludesSurgerySurcharge() {
        assertEquals(20500.00, elephant.calculateTotalCost(), 0.001);
    }

    @Test
    void injuredRescueCostWithoutSurgeryHasNoSurcharge() {
        InjuredAnimalRescue noSurgery = new InjuredAnimalRescue("WR103", "Duma", "Cheetah", "Limpopo",
                "Ranger Khoza", 2, 1000.00, "Sprained leg", 3000.00, false);
        assertEquals(5000.00, noSurgery.calculateTotalCost(), 0.001);
    }

    @Test
    void orphanedRescueCostIncludesFosterCareSurcharge() {
        assertEquals(11500.00, rhino.calculateTotalCost(), 0.001);
    }

    @Test
    void endangeredRescueCostIncludesSpecialistTeamSurcharge() {
        EndangeredSpeciesRescue pangolin = new EndangeredSpeciesRescue("WR104", "Scaly", "Pangolin",
                "Zululand", "Ranger Mokoena", 3, 2000.00,
                ConservationClassification.CRITICALLY_ENDANGERED, 4000.00, true);
        // 3 x 2 000 + 4 000 + 8 000
        assertEquals(18000.00, pangolin.calculateTotalCost(), 0.001);
    }

    // ----- Priority calculations -----

    @Test
    void injuredRescueWithSurgeryIsCritical() {
        assertEquals(RescuePriority.CRITICAL, elephant.determinePriority());
    }

    @Test
    void orphanedYoungAnimalIsHighPriority() {
        assertEquals(RescuePriority.HIGH, rhino.determinePriority());
    }

    @Test
    void orphanedOlderAnimalIsLowerPriority() {
        OrphanedAnimalRescue older = new OrphanedAnimalRescue("WR105", "Zuri", "Zebra", "Etosha",
                "Ranger Smith", 3, 800.00, 36, 1200.00, false);
        assertEquals(RescuePriority.LOW, older.determinePriority());
    }

    @Test
    void endangeredPriorityFollowsClassification() {
        EndangeredSpeciesRescue vulnerable = new EndangeredSpeciesRescue("WR106", "Lion", "Lion",
                "Kgalagadi", "Ranger Jacobs", 2, 900.00, ConservationClassification.VULNERABLE, 500.00, false);
        EndangeredSpeciesRescue endangered = new EndangeredSpeciesRescue("WR107", "Wild Dog", "African Wild Dog",
                "Kruger", "Ranger Jacobs", 2, 900.00, ConservationClassification.ENDANGERED, 500.00, false);
        assertEquals(RescuePriority.MEDIUM, vulnerable.determinePriority());
        assertEquals(RescuePriority.HIGH, endangered.determinePriority());
    }

    // ----- Status updates -----

    @Test
    void newCaseStartsAsReported() {
        assertEquals(RescueStatus.REPORTED, elephant.getStatus());
    }

    @Test
    void startRescueSetsStatusToInProgress() {
        elephant.startRescue();
        assertEquals(RescueStatus.IN_PROGRESS, elephant.getStatus());
    }

    @Test
    void completeRescueSetsStatusToCompleted() {
        elephant.startRescue();
        elephant.completeRescue();
        assertEquals(RescueStatus.COMPLETED, elephant.getStatus());
    }

    @Test
    void cannotCompleteARescueThatWasNeverStarted() {
        assertThrows(IllegalStateException.class, () -> elephant.completeRescue());
    }

    @Test
    void managerUpdatesStatusOfExistingCase() {
        manager.addCase(rhino);
        assertTrue(manager.updateStatus("WR102", RescueStatus.UNDER_OBSERVATION));
        assertEquals(RescueStatus.UNDER_OBSERVATION, rhino.getStatus());
    }

    @Test
    void updatingUnknownCaseReturnsFalse() {
        assertFalse(manager.updateStatus("NOPE", RescueStatus.COMPLETED));
    }

    // ----- Searching -----

    @Test
    void searchFindsExistingCase() {
        manager.addCase(elephant);
        manager.addCase(rhino);
        assertSame(rhino, manager.findById("WR102"));
    }

    @Test
    void searchIsNotCaseSensitive() {
        manager.addCase(elephant);
        assertSame(elephant, manager.findById("wr101"));
    }

    @Test
    void searchReturnsNullForMissingCase() {
        manager.addCase(elephant);
        assertNull(manager.findById("WR999"));
    }

    // ----- Duplicate IDs -----

    @Test
    void duplicateCaseIdIsRejected() {
        manager.addCase(elephant);
        InjuredAnimalRescue duplicate = new InjuredAnimalRescue("wr101", "Other", "Giraffe", "Kruger",
                "Ranger Dlamini", 1, 500.00, "Limp", 1000.00, false);
        assertThrows(IllegalArgumentException.class, () -> manager.addCase(duplicate));
        assertEquals(1, manager.getTotalCases());
    }

    // ----- Validation & report -----

    @Test
    void blankSpeciesIsRejected() {
        assertThrows(IllegalArgumentException.class, () ->
                new OrphanedAnimalRescue("WR108", "X", "  ", "Kruger", "Ranger A", 1, 100.00, 3, 100.00, false));
    }

    @Test
    void zeroDailyCostIsRejected() {
        assertThrows(IllegalArgumentException.class, () ->
                new OrphanedAnimalRescue("WR109", "X", "Rhino", "Kruger", "Ranger A", 1, 0, 3, 100.00, false));
    }

    @Test
    void reportTotalsMatchStoredCases() {
        manager.addCase(elephant);
        manager.addCase(rhino);
        assertEquals(2, manager.getTotalCases());
        assertEquals(32000.00, manager.getTotalRescueCost(), 0.001);
        assertTrue(manager.generateReport().contains("R32 000.00"));
    }
}
